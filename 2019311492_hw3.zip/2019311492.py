from __future__ import print_function
import sys
from optparse import OptionParser
import random
import math
import collections


# to make Python2 and Python3 act the same -- how dumb
def random_seed(seed):
    try:
        random.seed(seed, version=1)
    except:
        random.seed(seed)
    return


def convert(size):
    length = len(size)
    lastchar = size[length - 1]
    if (lastchar == 'k') or (lastchar == 'K'):
        m = 1024
        nsize = int(size[0:length - 1]) * m
    elif (lastchar == 'm') or (lastchar == 'M'):
        m = 1024 * 1024
        nsize = int(size[0:length - 1]) * m
    elif (lastchar == 'g') or (lastchar == 'G'):
        m = 1024 * 1024 * 1024
        nsize = int(size[0:length - 1]) * m
    else:
        nsize = int(size)
    return nsize


def hfunc(index):
    if index == -1:
        return 'MISS'
    else:
        return 'HIT '


def vfunc(victim):
    if victim == -1:
        return '-'
    else:
        return str(victim)


#
# main program
#
parser = OptionParser()
parser.add_option('-a', '--addresses', default='-1',
                  help='a set of comma-separated pages to access; -1 means randomly generate', action='store',
                  type='string', dest='addresses')
parser.add_option('-f', '--addressfile', default='', help='a file with a bunch of addresses in it', action='store',
                  type='string', dest='addressfile')
parser.add_option('-n', '--numaddrs', default='10',
                  help='if -a (--addresses) is -1, this is the number of addrs to generate', action='store',
                  type='string', dest='numaddrs')
# LFU 추가
parser.add_option('-p', '--policy', default='FIFO', help='replacement policy: FIFO, LRU, OPT, UNOPT, RAND, CLOCK, LFU',
                  action='store', type='string', dest='policy')
parser.add_option('-b', '--clockbits', default=2, help='for CLOCK policy, how many clock bits to use', action='store',
                  type='int', dest='clockbits')
parser.add_option('-C', '--cachesize', default='3', help='size of the page cache, in pages', action='store',
                  type='string', dest='cachesize')
parser.add_option('-m', '--maxpage', default='10',
                  help='if randomly generating page accesses, this is the max page number', action='store',
                  type='string', dest='maxpage')
parser.add_option('-s', '--seed', default='0', help='random number seed', action='store', type='string', dest='seed')
parser.add_option('-N', '--notrace', default=False, help='do not print out a detailed trace', action='store_true',
                  dest='notrace')
parser.add_option('-c', '--compute', default=False, help='compute answers for me', action='store_true', dest='solve')

(options, args) = parser.parse_args()

print('ARG addresses', options.addresses)
print('ARG addressfile', options.addressfile)
print('ARG numaddrs', options.numaddrs)
print('ARG policy', options.policy)
print('ARG clockbits', options.clockbits)
print('ARG cachesize', options.cachesize)
print('ARG maxpage', options.maxpage)
print('ARG seed', options.seed)
print('ARG notrace', options.notrace)
print('')

addresses = str(options.addresses)
addressFile = str(options.addressfile)
numaddrs = int(options.numaddrs)
cachesize = int(options.cachesize)
seed = int(options.seed)
maxpage = int(options.maxpage)
policy = str(options.policy)
notrace = options.notrace
clockbits = int(options.clockbits)

random_seed(seed)

addrList = []
if addressFile != '':
    fd = open(addressFile)
    for line in fd:
        addrList.append(int(line))
    fd.close()
else:
    if addresses == '-1':
        # need to generate addresses
        for i in range(0, numaddrs):
            n = int(maxpage * random.random())
            addrList.append(n)
    else:
        addrList = addresses.split(',')

if options.solve == False:
    print('Assuming a replacement policy of %s, and a cache of size %d pages,' % (policy, cachesize))
    print('figure out whether each of the following page references hit or miss')
    print('in the page cache.\n')

    for n in addrList:
        print('Access: %d  Hit/Miss?  State of Memory?' % int(n))
    print('')

else:
    if notrace == False:
        print('Solving...\n')

    # init memory structure
    count = 0
    memory = []
    hits = 0
    miss = 0

    if policy == 'FIFO':
        leftStr = 'FirstIn'
        riteStr = 'Lastin '
    elif policy == 'LRU':
        leftStr = 'LRU'
        riteStr = 'MRU'
    elif policy == 'MRU':
        leftStr = 'LRU'
        riteStr = 'MRU'
    elif policy == 'OPT' or policy == 'RAND' or policy == 'UNOPT' or policy == 'CLOCK':
        leftStr = 'Left '
        riteStr = 'Right'
    # LFU 알고리즘 부분 추가
    elif policy == 'LFU':
        leftStr = 'LFU'
        riteStr = 'MFU'
    else:
        print('Policy %s is not yet implemented' % policy)
        exit(1)

    # track reference bits for clock
    ref = {}

    cdebug = False

    # need to generate addresses
    addrIndex = 0
    for nStr in addrList:
        flag = 0    # LFU에서 페이지 교체했는지를 확인하기 위한 변수 (교체했다면 1, 아니면 0)
        # first, lookup
        n = int(nStr)
        try:
            idx = memory.index(n)
            hits = hits + 1
            if policy == 'LRU' or policy == 'MRU':
                update = memory.remove(n)
                memory.append(n)  # puts it on MRU side
        except:
            idx = -1
            miss = miss + 1

        victim = -1
        if idx == -1:
            # miss, replace?
            # print('BUG count, cachesize:', count, cachesize)
            if count == cachesize:
                # must replace
                if policy == 'FIFO' or policy == 'LRU':
                    victim = memory.pop(0)
                elif policy == 'MRU':
                    victim = memory.pop(count - 1)
                elif policy == 'RAND':
                    victim = memory.pop(int(random.random() * count))
                elif policy == 'CLOCK':
                    if cdebug:
                        print('REFERENCE TO PAGE', n)
                        print('MEMORY ', memory)
                        print('REF (b)', ref)

                    # hack: for now, do random
                    # victim = memory.pop(int(random.random() * count))
                    victim = -1
                    while victim == -1:
                        page = memory[int(random.random() * count)]
                        if cdebug:
                            print('  scan page:', page, ref[page])
                        if ref[page] >= 1:
                            ref[page] -= 1
                        else:
                            # this is our victim
                            victim = page
                            memory.remove(page)
                            break

                    # remove old page's ref count
                    if page in memory:
                        assert ('BROKEN')
                    del ref[victim]
                    if cdebug:
                        print('VICTIM', page)
                        print('LEN', len(memory))
                        print('MEM', memory)
                        print('REF (a)', ref)

                elif policy == 'OPT':
                    maxReplace = -1
                    replaceIdx = -1
                    replacePage = -1
                    # print('OPT: access %d, memory %s' % (n, memory) )
                    # print('OPT: replace from FUTURE (%s)' % addrList[addrIndex+1:])
                    for pageIndex in range(0, count):
                        page = memory[pageIndex]
                        # now, have page 'page' at index 'pageIndex' in memory
                        whenReferenced = len(addrList)
                        # whenReferenced tells us when, in the future, this was referenced
                        for futureIdx in range(addrIndex + 1, len(addrList)):
                            futurePage = int(addrList[futureIdx])
                            if page == futurePage:
                                whenReferenced = futureIdx
                                break
                        # print('OPT: page %d is referenced at %d' % (page, whenReferenced))
                        if whenReferenced >= maxReplace:
                            # print('OPT: ??? updating maxReplace (%d %d %d)' % (replaceIdx, replacePage, maxReplace))
                            replaceIdx = pageIndex
                            replacePage = page
                            maxReplace = whenReferenced
                            # print('OPT: --> updating maxReplace (%d %d %d)' % (replaceIdx, replacePage, maxReplace))
                    victim = memory.pop(replaceIdx)
                    # print('OPT: replacing page %d (idx:%d) because I saw it in future at %d' % (victim, replaceIdx, whenReferenced))
                elif policy == 'UNOPT':
                    minReplace = len(addrList) + 1
                    replaceIdx = -1
                    replacePage = -1
                    for pageIndex in range(0, count):
                        page = memory[pageIndex]
                        # now, have page 'page' at index 'pageIndex' in memory
                        whenReferenced = len(addrList)
                        # whenReferenced tells us when, in the future, this was referenced
                        for futureIdx in range(addrIndex + 1, len(addrList)):
                            futurePage = int(addrList[futureIdx])
                            if page == futurePage:
                                whenReferenced = futureIdx
                                break
                        if whenReferenced < minReplace:
                            replaceIdx = pageIndex
                            replacePage = page
                            minReplace = whenReferenced
                    victim = memory.pop(replaceIdx)
                # LFU policy 구현
                elif policy == "LFU":
                    present = addrList[:addrIndex]    # 현재 시점까지의 address list
                    frequency = collections.Counter(present)    # 현재 시점 이전까지의 frequency 구하기
                    # frequency가 작은 순서대로 정렬 (이때 같은 값일 경우 먼저 들어온 것이 앞에 위치한다.)
                    frequency = sorted(frequency.items(), key=lambda x: x[1])
                    i = 0   # frequency를 순회하기 위한 인덱스 초기화
                    while True:
                        victim = int(frequency[i][0])   # victim을 가장 앞에 있는 원소로 설정
                        if victim in memory:    # 해당 victim이 memory에 존재하면
                            replaceIdx = memory.index(victim)   # replaceIdx 업데이트
                            memory.remove(victim)   # memory에서 삭제
                            memory.insert(replaceIdx, n)    # 삭제한 페이지의 위치에 새로운 페이지 삽입
                            flag = 1    # 페이치 교체 했으므로 flag를 1로 설정
                            break   # 반복문을 빠져나옴
                        else:   # 만약 victim이 memory에 없으면
                            i += 1  # 다음으로 적은 frequency / frequency가 같은 경우 다음에 들어온 원소 설정
                        if i == len(frequency)-1:   # 만약 모든 frequency를 다 순회했는데 victim을 찾지 못했다면
                            assert (victim not in memory)   # 메모리에 victim이 없다는 메시지 출력
                    #continue    # 이미 페이지를 삽입했으므로 아래의 코드를 실행할 필요가 없다. 따라서 바로 다음 반복문 수행
            else:
                # miss, but no replacement needed (cache not full)
                victim = -1
                count = count + 1

            # now add to memory
            if flag == 0:
                memory.append(n)
            # LFU 알고리즘에서 페이지 교체를 했다면 내부에서 이미 새로운 페이지를 삽입했으므로 또 삽입하면 안된다. 그러므로 pass
            else:
                pass
            if cdebug:
                print('LEN (a)', len(memory))
            if victim != -1:
                assert (victim not in memory)

        # after miss processing, update reference bit
        if n not in ref:
            ref[n] = 1
        else:
            ref[n] += 1
            if ref[n] > clockbits:
                ref[n] = clockbits

        if cdebug:
            print('REF (a)', ref)

        if notrace == False:
            print('Access: %d  %s %s -> %12s <- %s Replaced:%s [Hits:%d Misses:%d]' % (
            n, hfunc(idx), leftStr, memory, riteStr, vfunc(victim), hits, miss))
        addrIndex = addrIndex + 1

    print('')
    print('FINALSTATS hits %d   misses %d   hitrate %.2f' % (
    hits, miss, (100.0 * float(hits)) / (float(hits) + float(miss))))
    print('')