from __future__ import print_function
import sys
from optparse import OptionParser
import random


# to make Python2 and Python3 act the same -- how dumb
def random_seed(seed):
    try:
        random.seed(seed, version=1)
    except:
        random.seed(seed)
    return


parser = OptionParser()
parser.add_option("-s", "--seed", default=0, help="the random seed", action="store", type="int", dest="seed")
parser.add_option("-j", "--jobs", default=3, help="number of jobs in the system", action="store", type="int",
                  dest="jobs")
parser.add_option("-l", "--jlist", default="",
                  help="instead of random jobs, provide a comma-separated list of run times", action="store",
                  type="string", dest="jlist")
parser.add_option("-m", "--maxlen", default=10, help="max length of job", action="store", type="int", dest="maxlen")
# STCF policy 추가
parser.add_option("-p", "--policy", default="FIFO", help="sched policy to use: SJF, FIFO, RR, STCF", action="store",
                  type="string", dest="policy")
parser.add_option("-q", "--quantum", help="length of time slice for RR policy", default=1, action="store", type="int",
                  dest="quantum")
parser.add_option("-c", help="compute answers for me", action="store_true", default=False, dest="solve")
# arrival time option 추가
parser.add_option("-a", "--arr", default="", action="store", type="string", dest="arr",
                  help="provide a comma-separated list of arrival time of each jobs (# of arrival times must be same with # of jobs)")

(options, args) = parser.parse_args()

random_seed(options.seed)

print('ARG policy', options.policy)
if options.jlist == '':
    print('ARG jobs', options.jobs)
    print('ARG maxlen', options.maxlen)
    print('ARG seed', options.seed)
else:
    print('ARG jlist', options.jlist)
print('')

print('Here is the job list, with the run time of each job: ')

import operator

if options.arr == '':   # 만약 arrival time을 입력하지 않았다면
    arrtime = []    # 빈 arrtime 리스트 생성
    for i in range(options.jobs):   # job의 개수 만큼 반복
        arrtime.append(0)   # arrtime 리스트에 0을 append(defalut : 0)
else:   # arrival time 입력 시
    # arrtime 리스트 생성
    arrtime = options.arr.split(',')
    arrtime = list(map(int, arrtime))
    # 만약 arrtime 리스트의 개수와 job의 개수가 불일치 할 때 에러 발생
    if len(arrtime) != options.jobs:
        print('Error: # of arrival time and # of jobs are not same')
        sys.exit(0)

joblist = []

if options.jlist == '':
    for jobnum in range(0, options.jobs):
        runtime = int(options.maxlen * random.random()) + 1
        joblist.append([jobnum, runtime, arrtime[jobnum]])
        # jobnum, length, arrival time 출력
        print('  Job', jobnum, '( length = ' + str(runtime) + ', arrival = ' + str(arrtime[jobnum]) + ' )')
else:
    jobnum = 0
    for runtime in options.jlist.split(','):
        joblist.append([jobnum, float(runtime), arrtime[jobnum]])   # arrival time 추가
        jobnum += 1
    for job in joblist:
        # jobnum, length, arrival time 출력
        print('  Job', job[0], '( length = ' + str(job[1]) + ', arrival = ' + str(job[2]) + ' )')
print('\n')

# SJF 알고리즘이 STCF에서도 사용되어 함수로 정의함
def sjf(joblist):
    thetime = 0
    joblist = sorted(joblist, key=operator.itemgetter(1))
    print('Execution trace:')
    # 아래 코드는 FIFO와 동일
    for job in joblist:
        print('  [ time %3d ] Run job %d for %.2f secs ( DONE at %.2f )' % (
            thetime, job[0], job[1], thetime + job[1]))
        thetime += job[1]

    print('\nFinal statistics:')
    t = 0
    count = 0
    turnaroundSum = 0.0
    waitSum = 0.0
    responseSum = 0.0
    for tmp in joblist:
        jobnum = tmp[0]
        runtime = tmp[1]

        response = t
        turnaround = t + runtime
        wait = t
        print('  Job %3d -- Response: %3.2f  Turnaround %3.2f  Wait %3.2f' % (jobnum, response, turnaround, wait))
        responseSum += response
        turnaroundSum += turnaround
        waitSum += wait
        t += runtime
        count = count + 1
    print('\n  Average -- Response: %3.2f  Turnaround %3.2f  Wait %3.2f\n' % (
        responseSum / count, turnaroundSum / count, waitSum / count))

if options.solve == True:
    print('** Solutions **\n')
    if options.policy == 'SJF': # policy가 SJF 일 때 sjf 함수 호출
        sjf(joblist)

    if options.policy == 'FIFO':
        thetime = 0
        # arrival time 기준으로 정렬
        joblist.sort(key= lambda x:x[2])
        print('Execution trace:')
        for job in joblist:
            print('  [ time %3d ] Run job %d for %.2f secs ( DONE at %.2f )' % (
            thetime, job[0], job[1], thetime + job[1]))
            thetime += job[1]

        print('\nFinal statistics:')
        t = 0
        count = 0
        turnaroundSum = 0.0
        waitSum = 0.0
        responseSum = 0.0
        for tmp in joblist:
            jobnum = tmp[0]
            runtime = tmp[1]

            response = t
            turnaround = t + runtime
            wait = t
            print('  Job %3d -- Response: %3.2f  Turnaround %3.2f  Wait %3.2f' % (jobnum, response, turnaround, wait))
            responseSum += response
            turnaroundSum += turnaround
            waitSum += wait
            t += runtime
            count = count + 1
        print('\n  Average -- Response: %3.2f  Turnaround %3.2f  Wait %3.2f\n' % (
        responseSum / count, turnaroundSum / count, waitSum / count))

    if options.policy == 'RR':
        print('Execution trace:')
        turnaround = {}
        response = {}
        lastran = {}
        wait = {}
        quantum = float(options.quantum)
        jobcount = len(joblist)
        for i in range(0, jobcount):
            lastran[i] = 0.0
            wait[i] = 0.0
            turnaround[i] = 0.0
            response[i] = -1

        runlist = []
        thetime = 0.0
        # arrival time에 도달하지 않은 job들을 보관하는 joblist_copied 생성
        joblist_copied = joblist.copy()
        while jobcount > 0:
            # arrival time에 도달하지 않은 job 순회
            for e in joblist_copied:
                if e[2] <= thetime: # 만약 현재 시간이 arrival time보다 크거나 같으면
                    runlist.insert(0, e)    # run list에 job 추가
                    joblist_copied.remove(e)    # 해당 job을 joblist_copied 리스트에서 제거
            if len(runlist) == 0:   # 만약 모든 job들이 arrival time에 도달하지 못했을 때
                thetime += 1.0  # 현재 시간을 1씩 증가
            else:   # 만약 어떤 job이 ranlist에 들어왔을 때
                job = runlist.pop(0)
                jobnum = job[0]
                runtime = float(job[1])
                if response[jobnum] == -1:
                    response[jobnum] = thetime
                currwait = thetime - lastran[jobnum]
                wait[jobnum] += currwait
                if runtime > quantum:
                    runtime -= quantum
                    ranfor = quantum
                    print('  [ time %3d ] Run job %3d for %.2f secs' % (thetime, jobnum, ranfor))
                    runlist.append([jobnum, runtime])
                else:
                    ranfor = runtime;
                    print('  [ time %3d ] Run job %3d for %.2f secs ( DONE at %.2f )' % (
                    thetime, jobnum, ranfor, thetime + ranfor))
                    turnaround[jobnum] = thetime + ranfor
                    jobcount -= 1
                thetime += ranfor
                lastran[jobnum] = thetime


        print('\nFinal statistics:')
        turnaroundSum = 0.0
        waitSum = 0.0
        responseSum = 0.0
        for i in range(0, len(joblist)):
            turnaroundSum += turnaround[i]
            responseSum += response[i]
            waitSum += wait[i]
            print('  Job %3d -- Response: %3.2f  Turnaround %3.2f  Wait %3.2f' % (i, response[i], turnaround[i], wait[i]))

        count = len(joblist)
        print('\n  Average -- Response: %3.2f  Turnaround %3.2f  Wait %3.2f\n' % (
        responseSum / count, turnaroundSum / count, waitSum / count))

    # STCF 구현
    if options.policy == 'STCF':
        joblist_copied = joblist.copy() # arrival time에 도착하지 않은 job을 확인하기 위해 joblist_copied 생성
        # arrival time -> run time 기준으로 정렬
        joblist_copied = sorted(joblist_copied, key=lambda x: (x[2], x[1]))
        # 남은 run time을 관리하기 위한 리스트
        lefttime = []
        # 가장 도착 시간이 빠른 job을 lefttime에 append
        lefttime.append(joblist_copied[0])
        # job들의 arrival time만 저장 (빠른 순대로)
        arrtime = [row[2] for row in joblist_copied]
        # 만약 모든 job들의 arrival time이 같은 경우
        if len(set(arrtime)) == 1:
            sjf(joblist)    # sjf 함수 호출
            sys.exit(0) # 종료
        joblist_copied.pop(0)   # 가장 빠른 arrival time인 job 삭제
        arrtime.pop(0)  # arrival time에서도 삭제
        thetime = 0 # 현재 시간 초기화

        # turnaround time, response time, wait 계산을 위해 초기화 (respone 초기화 빼고 위의 알고리즘들과 코드 동일)
        turnaround = {}
        response = {}
        lastran = {}
        wait = {}
        jobcount = len(joblist)

        for i in range(0, jobcount):
            lastran[i] = 0.0
            wait[i] = 0.0
            turnaround[i] = 0.0
            response[i] = float("inf")  # response를 양의 무한대로 초기화

        # 모든 job들이 실행이 끝날 때까지 반복
        """
        lefttime[0][0] : job name
        lefttime[0][1] : job run time (left)
        lefttime[0][2] : job arrival time
        """
        while jobcount > 0:
            if len(lefttime) > 0:   # 만약 현재 실행 가능한 job들이 있다면
                runtime = int(lefttime[0][1])   # 남은 run time을 변수에 할당
                run = 0
                for i in range(runtime):    # runtime 만큼 반복
                    # 현재 실행하려는 job이 처음 도착한건지 확인하고 맞다면 현재 시간을 response에 할당
                    if response[lefttime[0][0]] < thetime:
                        pass
                    else:
                        response[lefttime[0][0]] = thetime
                    thetime += 1    # 현재 시간 1 증가
                    lastran[lefttime[0][0]] += 1    # 실행 시간 1 증가
                    lefttime[0][1] -= 1 # 남은 시간 1 감소
                    if lefttime[0][1] == 0: # 만약 job의 실행이 끝났다면
                        jobcount -= 1   # job count 감소
                        # 끝남을 출력
                        print('  [ time %3d ] Run job %3d for %.2f secs(done)' % (thetime, lefttime[0][0], lastran[lefttime[0][0]]))
                        turnaround[lefttime[0][0]] = thetime - lefttime[0][2]   # turnaround 할당
                        wait[lefttime[0][0]] = turnaround[lefttime[0][0]] - lastran[lefttime[0][0]] # wait 할당
                        lefttime.pop(0) # 해당 job을 lefttime에서 삭제
                    for i in arrtime:   # 어떤 job을 실행하는 도중 arrival time에 도달한 job이 있는지 확인
                        if i==thetime:  # 있다면
                            lefttime.append(joblist_copied[0])  # 해당 job을 lefttime에 append
                            joblist_copied.pop(0)   # arrival time에 도달하지 않은 job을 보관하는 joblist에서 해당 job 삭제
                            lefttime.sort(key=lambda x: x[1])   # lefttime을 남은 run time을 기준으로 재정렬

            else:   # 만약 현재 실행 가능한 job이 없다면 (해당 시간에 arrival time에 도달하지 못한 job들만 존재)
                thetime += 1    # 현재 시간 1 증가
                for i in arrtime:   # arrival time 리스트에서 도착 시간에 도달한 job이 있는지 하ㅗㄱ인
                    if i == thetime:    # 있다면
                        lefttime.append(joblist_copied[0])  # 해당 job을 lefttime에 append
                        joblist_copied.pop(0)   # arrival time에 도달하지 않은 job을 보관하는 joblist에서 해당 job 삭제
                        lefttime.sort(key=lambda x: x[1])   # lefttime을 남은 run time을 기준으로 재정렬

        # 아래 코드는 performance 계산하는 부분이고 위의 알고리즘들과 동일
        print('\nFinal statistics:')
        turnaroundSum = 0.0
        waitSum = 0.0
        responseSum = 0.0
        for i in range(0, len(joblist)):
            turnaroundSum += turnaround[i]
            responseSum += response[i]
            waitSum += wait[i]
            print(
                '  Job %3d -- Response: %3.2f  Turnaround %3.2f  Wait %3.2f' % (i, response[i], turnaround[i], wait[i]))

        count = len(joblist)
        print('\n  Average -- Response: %3.2f  Turnaround %3.2f  Wait %3.2f\n' % (
            responseSum / count, turnaroundSum / count, waitSum / count))


    # STCF policy 추가
    if options.policy != 'FIFO' and options.policy != 'SJF' and options.policy != 'RR' and options.policy != "STCF":
        print('Error: Policy', options.policy, 'is not available.')
        sys.exit(0)
else:
    print('Compute the turnaround time, response time, and wait time for each job.')
    print('When you are done, run this program again, with the same arguments,')
    print('but with -c, which will thus provide you with the answers. You can use')
    print('-s <somenumber> or your own job list (-l 10,15,20 for example)')
    print('to generate different problems for yourself.')
    print('')